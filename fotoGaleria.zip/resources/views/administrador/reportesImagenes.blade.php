@extends('layouts.panel')
@section('contenido')
@include('layouts.partials.enlacesReportes')  

@endsection