<div id="carouselExampleIndicators" class="carousel slide h-100 position-relative" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner h-100">
                    <div class="carousel-item  h-100 active">
                    <img class="d-block w-100 h-100" src="{{asset('images/login-carousel1.jpg')}}" alt="First slide">
                    </div>
                    <div class="carousel-item  h-100">
                    <img class="d-block w-100 h-100" src="{{asset('images/login-carousel2.jpg')}}" alt="Second slide">
                    </div>
                    <div class="carousel-item  h-100">
                    <img class="d-block w-100 h-100" src="{{asset('images/login-carousel3.jpg')}}" alt="Third slide">
                    </div>


                    
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
                

                <form action="" class="position-absolute d-flex p-4 w-75"  style="top:44%; left:12.5%; background-color:rgba(201,1,27,0.5);">
                    <button class="btn p-2" style="border-radius:0; border-right:none; background-color:rgb(201,1,27);">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="bi bi-search" viewBox="0 0 16 16">
                            <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
                        </svg>
                    </button>
                    <input class="form-control  w-100 p-2" style="border-radius:0; border:none;" type="text" placeholder="Buscar fotografia...">
                </form>


                <div class="position-absolute w-100 " style="top:5%;">
                    <ul class="pl-0 d-flex lead text-center" style=" list-style: none; color:white;">
                        <li class="w-100"><a href="" style="color:white;">Belico</a></li>
                        <li class="w-100"><a href="" style="color:white;">Ambiente</a></li>
                        <li class="w-100"><a href="" style="color:white;">Economia</a></li>
                        <li class="w-100"><a href="" style="color:white;">Deportes</a></li>
                        <li class="w-100"><a href="" style="color:white;">Lugares</a></li>
                    </ul>
                </div>



                <div class="position-absolute w-100" style="bottom:5%; left:6%; color:white;">
                
                    <p>Fotografias de <a href="" data-toggle="modal" data-target="#exampleModal">Leopoldo pinedo</a></p>
                </div>
                <!-- Modal -->
                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Fotografo Leopoldo Pinedo</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        
                            <div class="modal-body">
                                aqui tengo que ver que diseño invento
                            </div>
                            <div class="modal-footer">
                                <a href="" class="btn btn-success" >Ver mas</a>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
</div>