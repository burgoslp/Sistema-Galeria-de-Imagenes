<?php $__env->startSection('contenido'); ?>

<div class="row h-75">
    <div class="col d-flex flex-column justify-content-center align-items-center">
                    
        <div class="mb-4">
            <img src="<?php echo e(asset('images/login-logo.png')); ?>" alt="">
        </div>

        <div class="w-75  mt-4">
            <form class="w-100 " method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
                <input id="email"  name="email" type="text" class="form-control mb-4 p-2 <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Usuario" aria-label="Username" aria-describedby="basic-addon1">
                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                <input  id="password" name="password" type="password" class="form-control mb-4 p-2 <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Contraseña" aria-label="Username" aria-describedby="basic-addon1">
                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                <div class="d-flex justify-content-end mb-4">
                    <input class="btn btn-dark mb-4 mb-md-1" type="submit" value="Iniciar sesion">
                </div>

                <div>
                    <a href="<?php echo e(route('password.request')); ?>">olvidaste tu contraseña?</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.autentificacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fotoGaleria\resources\views/login/index.blade.php ENDPATH**/ ?>