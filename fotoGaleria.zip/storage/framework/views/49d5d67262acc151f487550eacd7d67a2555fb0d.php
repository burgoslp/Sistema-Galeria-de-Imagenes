<?php $__env->startSection('contenido'); ?>
<?php echo $__env->make('layouts.partials.enlacesReportes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fotoGaleria\resources\views/administrador/reportes.blade.php ENDPATH**/ ?>