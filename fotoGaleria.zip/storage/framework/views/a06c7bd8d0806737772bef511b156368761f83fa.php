<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModal" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModal">Cargar nueva fotografía </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="form-crearfoto" enctype="multipart/form-data" action="<?php echo e(url($url)); ?>" method="POST" >
        <?php echo csrf_field(); ?>
        <input type="hidden" name="estatu_id" value="2">
            <span>Autor:</span>
            <select name="persona_id" class="form-control">
                <option value="-1">Seleccione</option>
                <?php $__currentLoopData = $fotografos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fotografo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($fotografo->id); ?>"><?php echo e($fotografo->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br>
            
            <span>Colección:</span>
            <select name="coleccione_id" class="form-control">
                <option>Seleccione</option>
                <?php $__currentLoopData = $colecciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coleccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($coleccion->id); ?>"><?php echo e($coleccion->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><br>

            <span>Categoria:</span>
            <select name="categoria_id" class="form-control">
                <option>Seleccione</option>
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->descripcion); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><br>

            <div class="form-group">
                <label for="exampleFormControlTextarea1">Descripción</label>
                <textarea name="descripcion" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
            </div>

           

            <div class="form-group">

                <label for="">Locación</label>
                <input class="form-control" name="locacion" type="text">
            </div>

            <div class="form-group">
                <label for="">Fecha</label>
                <input class="form-control" name="fecha" type="text">
            </div>

            <div class="form-group">
                <label for="exampleFormControlFile1">Elige la fotografia</label>
                <input type="file" name="file" class="form-control-file" >
            </div>
        </form>
      </div>
      <div class="modal-footer">
        <button form="form-crearfoto" type="submit" class="btn btn-primary">Guardar</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\fotoGaleria\resources\views/layouts/partials/modalCrear.blade.php ENDPATH**/ ?>