<?php $__env->startSection('contenido'); ?>
<div class="row pl-md-5">
        <?php $__currentLoopData = $fotografos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fotografo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $fotografo->foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fotos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-auto pt-4 pl-5">
                    <div class="card" style="width: 18rem; ">
                        <img class="card-img-top" style="height:18rem;" src="<?php echo e(asset('images/fotografias/'.$fotografo->id.'/'.$fotos->url)); ?>" alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-title">Author <br><?php echo e($fotografo->nombre); ?> <?php echo e($fotografo->apellido); ?></h5>
                            <p class="card-text">Fecha <br><?php echo e($fotos->fecha); ?> </p>
                            <p  class="card-text">Descripción: <br> <?php echo e($fotos->descripcion); ?></p>
                            <p  class="card-text">lugar: <br> <?php echo e($fotos->locacion); ?></p>
                            <?php if($fotos->estatu_id==2): ?>
                                <form class="d-inline" action="<?php echo e(url('/operador/fotografia/publicar')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="put" />
                                    <input type="hidden" value="<?php echo e($fotos->id); ?>" name="id">
                                    <button class="btn btn-primary" type="submit">Publicar</button>
                                </form>
                            <?php else: ?>
                                <form class="d-inline" action="<?php echo e(url('/operador/fotografia/publicar')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="put" />
                                    <input type="hidden" value="<?php echo e($fotos->id); ?>" name="id">
                                    <button class="btn btn-primary" type="submit">Ocultar</button>
                                </form>
                            <?php endif; ?>
                            <form class="d-inline" action="<?php echo e(url('/operador/fotografia/eliminar')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="delete" />
                                <input type="hidden" value="<?php echo e($fotos->id); ?>" name="id">
                                <button class="btn btn-danger" type="submit">Eliminar</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modales'); ?>
<!--Modales para crear fotografias-->
<?php echo $__env->make('layouts.partials.modalCrear',["url"=>'operador/fotografia'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fotoGaleria\resources\views/operador/index.blade.php ENDPATH**/ ?>