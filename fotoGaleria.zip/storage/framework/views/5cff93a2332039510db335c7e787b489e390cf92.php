<div class="modal fade" id="modalcrearfotografo" tabindex="-1" role="dialog" aria-labelledby="modalcrearfotografoLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalcrearfotografoLabel">Crear nuevo fotografo</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="form-crearfoto" enctype="multipart/form-data" action="<?php echo e(url('/admin/fotografo')); ?>" method="POST" >
        <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="">Nombre</label>
                <input class="form-control" name="nombre" type="text">
            </div>
            <div class="form-group">
                <label for="">Apellido</label>
                <input class="form-control" name="apellido" type="text">
            </div>
            
            <div class="form-group">
                <label for="">Cedula</label>
                <input class="form-control" name="cedula" type="text">
            </div>

            <div class="form-group">
                <label for="">Correo</label>
                <input class="form-control" name="correo" type="text">
            </div>

            <div class="form-group">
              <label for="">Datos civiles</label>
              <select name="dat_civile_id" id="" class="custom-select w-100">
                <?php $__currentLoopData = $civiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $civil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($civil->id); ?>"><?php echo e($civil->descripcion); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="form-group">
              <label for="">Tipo de sexo</label>
              <select name="dat_sexo_id" id="" class="custom-select w-100">
                <?php $__currentLoopData = $sexos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sexo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($sexo->id); ?>"><?php echo e($sexo->descripcion); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
        </form>
      </div>
      <div class="modal-footer">
        <button form="form-crearfoto" type="submit" class="btn btn-primary">Crear</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\fotoGaleria\resources\views/layouts/partials/modalCrearFotografo.blade.php ENDPATH**/ ?>