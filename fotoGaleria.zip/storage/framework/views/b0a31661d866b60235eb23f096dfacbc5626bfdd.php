<div class="row pl-md-5 pt-5">
    <div class="col pl-5 pr-5">
        <ul class="nav nav-tabs">
            <li class="nav-item">
                <a class="nav-link active" href="#">Reportes</a>
            </li>
           <li>
            <?php if(Route::is('reportesFotografos')): ?>
                <a class="nav-link d-flex align-items-center" href="#" data-toggle="modal" data-target="#modalreportesfotografos">
                    <svg xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" fill="currentColor" class="bi bi-camera" viewBox="0 0 16 16">
                        <path d="M15 12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h1.172a3 3 0 0 0 2.12-.879l.83-.828A1 1 0 0 1 6.827 3h2.344a1 1 0 0 1 .707.293l.828.828A3 3 0 0 0 12.828 5H14a1 1 0 0 1 1 1v6zM2 4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-1.172a2 2 0 0 1-1.414-.586l-.828-.828A2 2 0 0 0 9.172 2H6.828a2 2 0 0 0-1.414.586l-.828.828A2 2 0 0 1 3.172 4H2z"/>
                        <path d="M8 11a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5zm0 1a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zM3 6.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0z"/>
                    </svg>
                </a>
            <?php endif; ?>
           </li>
        </ul>
    </div>
</div>
<div class="row pl-md-5">
    <div class="col pl-5 pt-2">
       <a href="<?php echo e(url('admin/reportes/fotografos')); ?>" class="pl-3 pr-5">Fotografos</a>
       <a href="<?php echo e(url('admin/reportes/imagenes')); ?>" class="pr-5">Imagenes</a>
       <a href="" class="pr-5">publicaciones</a>
       <a href="">Eliminaciones</a>
    </div>
</div><?php /**PATH C:\xampp\htdocs\fotoGaleria\resources\views/layouts/partials/enlacesReportes.blade.php ENDPATH**/ ?>