<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use  App\foto;
use App\User;
use App\persona;
use App\categoria;
use App\dat_sexo;
use App\dat_civile;
use App\role;
use App\coleccione;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
class administradorController extends Controller
{
    

    public function index(){
        
        $fotos=foto::all();
        $fotografos=persona::with('foto')->get();
        $colecciones=coleccione::all();
        $categorias=categoria::all();
        return view('administrador.index',compact('fotos','fotografos','colecciones','categorias'));
    }

    public function crearFoto(Request $request){

        $data=$request->all();
        if ($imagen=$request->file('file')) {
            $ruta="images/fotografias/";
            $ruta.=$request->persona_id;
            if(!file_exists($ruta)){
                mkdir($ruta);
            }
            
            $nombre_imagen=$imagen->getClientOriginalName();
            $imagen->move($ruta,$nombre_imagen);
            $data['url']=$nombre_imagen;
        }
        
        $data['coleccione_id']=$request->coleccione_id;
        foto::create($data);
        return redirect('/admin');
    }

    public function crearMultiplesFotos(Request $request){
        $fotografias=$request->file('archivo');
        $data=$request->all();
        if($request->coleccione_id=="Seleccione"){
            $data['coleccione_id']=null;
        }
        
        $ruta="images/fotografias/";
        $ruta.=$request->persona_id;
        if(!file_exists($ruta)){
            mkdir($ruta);
        }
        foreach($fotografias as $fotografia){
            $nombre_imagen=$fotografia->getClientOriginalName();
            $fotografia->move($ruta,$nombre_imagen);
            $data['url']=$nombre_imagen;
            foto::create($data);
        }
        return redirect('/admin');
    }

    public function eliminarFoto(Request $request){

        $idFoto=$request->id;
        $foto=foto::find($idFoto);
        $foto->delete();
        return redirect('/admin');

    }

    public function estatusFoto(Request $request){
        
        $idFoto=$request->id;
        $foto=foto::find($idFoto);
        if($foto->estatu_id==2){
            $foto->estatu_id=1;
        }else{
            $foto->estatu_id=2;
        }
        $foto->save();
        return redirect('/admin');
    }


    public function papelera(){

        $fotos=foto::onlyTrashed()->get();
        $fotografos=persona::all();
        return view('administrador.papelera',compact('fotos'));
    }

    public function restaurarFoto(Request $request){

        $foto=foto::withTrashed()->where('id',$request->id)->restore();
       return redirect('/admin/papelera');
    }


    public function vaciarFotos(Request $request){

        
        $fotos=foto::onlyTrashed()->forceDelete();
        return redirect('/admin/papelera');
    }


    public function fotografos(){
        $fotografos=persona::all();
        $sexos=dat_sexo::all();
        $civiles=dat_civile::all();
        return view('administrador.fotografos',compact('fotografos','civiles','sexos'));
    }

    public function categorias(){

        $categorias=categoria::all();
        return view('administrador.categorias',compact('categorias'));
    }

    public function crearCategoria(Request $request){

        $data=$request->all();
        categoria::create($data);
        return redirect('admin/categorias');
    }

    public function crearFotografo(Request $request){

        $data=$request->all();
        persona::create($data);
        return redirect('admin/fotografos');
    }

    public function generos(){

        $generos=dat_sexo::all();
        return view('administrador.generos',compact('generos'));
    }

    public function crearGenero(Request $request){
        $data=$request->all();
        dat_sexo::create($data);
        return redirect('admin/generos');
    }

    public function estatus(){
        $estatus=dat_civile::all();

        return view('administrador.estatus',compact('estatus'));
    }

    public function crearEstatus(Request $request){

        $data=$request->all();
        dat_civile::create($data);
        return redirect('admin/estatus');
    }

    public function usuarios(){
        
        $usuarios=User::all();
        $roles=role::all();
        return view('administrador.usuarios',compact('usuarios','roles'));
    }

    public function crearUsuarios(Request $request){
        
        $data=$request->all();

        $user= new User;
        $user->name=$data['name'];
        $user->email=$data['email'];
        $user->password=bcrypt($data['password']);
        $user->save();
        $user->roles()->attach(Role::where('id',$data['id_role'])->first());
        return redirect('admin/usuarios');
    }

    public function eliminarUsuarios(Request $request){
        
        $user=User::find($request->id);
        $user->delete();
        return redirect('admin/usuarios');
    }  

    public function eliminarEstatus(Request $request){

        $dat_civile=dat_civile::find($request->id);
        $dat_civile->delete();
        return redirect('admin/estatus');
    }

    public function eliminarGeneros(Request $request){

        $dat_sexo=dat_sexo::find($request->id);
        $dat_sexo->delete();
        return redirect('admin/generos');
    }

    public function eliminarCategorias(Request $request){

        $categoria=categoria::find($request->id);
        $categoria->delete();
        return redirect('admin/categorias');

    }

    public function eliminarFotografos(Request $request){
        $fotografo=persona::find($request->id);
        $fotografo->delete();
        return redirect('admin/fotografos');
    }

    public function colecciones(){

        $colecciones=coleccione::all();
        
        return view('administrador.colecciones',compact('colecciones'));
    }

    public function crearColecciones(Request $request){
       
        $data=$request->all();

        $coleccion=new coleccione;
        $coleccion->nombre=$request->nombre;
        $coleccion->descripcion=$request->descripcion;
        $coleccion->fecha=$request->fecha;
        $coleccion->save();
        return redirect('admin/colecciones');
    }

    public function eliminarColecciones(Request $request){

        $coleccion=coleccione::find($request->id);
        foreach($coleccion->fotos as $foto){
            $fotografia=foto::find($foto->id);
            $fotografia->coleccione_id=null;
            $fotografia->save();
        }   
        $coleccion->delete();
        return redirect('admin/colecciones');
    }

    public function verColecciones($id){

        $coleccion=coleccione::find($id);
        return view('administrador.coleccion',compact('coleccion'));
    }

    public function eliminarColeccion(Request $request){

        $foto=foto::find($request->id);
        $foto->coleccione_id=null;
        $foto->save();
        return redirect('admin/coleccion/'.$request->coleccione_id);
    }

    public function agregarColeccion($id){

        $fotos=foto::where('coleccione_id',null)->get();
        return view('administrador.agregarcoleccion',compact('fotos','id'));
    }

    public function agregarfotoColeccion(Request $request){

        $foto=foto::find($request->id);
        $foto->coleccione_id=$request->coleccione_id;
        $foto->save();
        return redirect('/admin/agregar/coleccion/'.$request->coleccione_id);
    }

    public function fotosPublicadas(){

        $fotos=foto::where('estatu_id',1)->get();
        return view('administrador.publicaciones',compact('fotos'));
    }


    public function contenido(){

        echo "todo bien";
    }


    public function reportes(){

        return view('administrador.reportes');
    }

    public function reportesfotografos(){
        $fotografos=persona::all();
        return view('administrador.reportesFotografo',compact('fotografos'));
    }

    public function reportesimagenes(){
        return view('administrador.reportesImagenes');
    }
}
